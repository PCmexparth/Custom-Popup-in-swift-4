//
//  ViewController.swift
//  Custom Popup
//
//  Created by Parth Changela on 11/05/19.
//  Copyright © 2019 parth. All rights reserved.
//

import UIKit

class ViewController: UIViewController,PopupDeleget {
   
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    func closeTapped() {
        self.dismissPopupViewController(animationType: SLpopupViewAnimationType.Fade)
    }
    @IBAction func btnOpenTapped(_ sender: Any) {
        var MYpopupView:PopupViewController!
        MYpopupView = PopupViewController(nibName:"PopupViewController", bundle: nil)
        self.view.alpha = 1.0
        MYpopupView.closePopup = self
        self.presentpopupViewController(popupViewController: MYpopupView, animationType: .BottomTop, completion: {() -> Void in
        })
        
    }
    
}

